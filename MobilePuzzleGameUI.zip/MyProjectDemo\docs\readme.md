﻿# MyProjectDemo

This project serves as an example of creating a folder structure and adding files with content using PowerShell.
