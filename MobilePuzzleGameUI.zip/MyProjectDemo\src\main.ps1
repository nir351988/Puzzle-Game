﻿# Main script for MyProjectDemo
Write-Output "Hello, welcome to MyProjectDemo!"
